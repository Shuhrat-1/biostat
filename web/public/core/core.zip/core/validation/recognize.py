"""Распознаватели для карты выбора метода (decision-tree-spec v2, раздел 5).

Распознаватель — одно правило «признак в данных → какую ветку дерева он
подсказывает». Здесь каркас: описание правила, контекст с ролями колонок
и функция :func:`recognize`, которую вызывает мост. Сами правила — в
``core/validation/recognizers.py``; реестр (id, сила, источник) — единый
источник правды для карты.

Роли — слоты формы метода (``value``, ``group``, ``block``, ``x`` …):
какую колонку пользователь назначил на какую роль. Без ролей работают
только правила уровня всего файла (имена колонок, состав типов).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import cached_property
from numbers import Integral
from typing import Any, Callable

import numpy as np

from core.validation.messages import msg
from core.validation.types import is_missing, parse_number

STRONG, HINT = "strong", "hint"
_ERROR_LIMIT = 200  # символов текста исключения в ответе recognize()
STRUCTURAL, COMPUTED = "structural", "computed"

# Слоты формы, которые означают отклик / основной фактор. Состав обязан
# совпадать с web/src/roleFamilies.json (проверяет tests/test_recognize.py):
# фронт по той же таблице вытесняет прежний отклик новым.
_RESPONSE_SLOTS = ("value", "y", "response", "count")
_FACTOR_SLOTS = ("group", "factor_a")


@dataclass(frozen=True)
class Signal:
    """Сработавший распознаватель: что подсказывает и почему."""

    note: str  # русский текст-фолбэк
    params: dict[str, Any] = field(default_factory=dict)
    # Сила этого срабатывания, если она отличается от силы правила в реестре:
    # тот же признак на малой выборке — подсказка, а не уверенное указание.
    strength: str | None = None


Rule = Callable[["Context"], "Signal | None"]


@dataclass(frozen=True)
class Recognizer:
    """Строка реестра; ``fn`` = None — правило пока только описано."""

    id: str
    node: str
    suggests: str
    strength: str
    cls: str
    source: str
    since: str = "1"
    fn: Rule | None = None

    def meta(self) -> dict[str, Any]:
        """Метаданные для фронта (без функции)."""
        return {k: getattr(self, k) for k in
                ("id", "node", "suggests", "strength", "cls", "source", "since")}


REGISTRY: list[Recognizer] = []


def rule(id: str, node: str, suggests: str, strength: str, source: str,
         cls: str = STRUCTURAL) -> Callable[[Rule], Rule]:
    """Декоратор: зарегистрировать функцию как распознаватель."""

    def wrap(fn: Rule) -> Rule:
        REGISTRY.append(Recognizer(id, node, suggests, strength, cls, source, fn=fn))
        return fn

    return wrap


def declare(id: str, node: str, suggests: str, strength: str, source: str,
            cls: str = COMPUTED) -> None:
    """Описать правило без реализации (расчётные — этап 2 карты)."""
    REGISTRY.append(Recognizer(id, node, suggests, strength, cls, source))


class Context:
    """Таблица и роли колонок с кэшированными выборками значений."""

    def __init__(self, table: Any, roles: dict[str, str] | None = None,
                 method: str | None = None) -> None:
        self.table = table
        names = set(table.header)
        self.roles = {k: v for k, v in (roles or {}).items() if v in names}
        self.method = method  # метод, открытый в форме (если карта его знает)
        # Общие для нескольких правил расчёты (подгонка модели): ключ → результат.
        self.cache: dict[str, Any] = {}

    def memo(self, key: str, compute: Callable[[], Any]) -> Any:
        """Посчитать один раз на вызов recognize (модель нужна многим правилам)."""
        if key not in self.cache:
            self.cache[key] = compute()
        return self.cache[key]

    def role(self, *slots: str) -> str | None:
        """Первая назначенная колонка из перечня слотов."""
        return next((self.roles[s] for s in slots if s in self.roles), None)

    @property
    def response(self) -> str | None:
        return self.role(*_RESPONSE_SLOTS)

    @property
    def factor(self) -> str | None:
        return self.role(*_FACTOR_SLOTS)

    def numbers(self, column: str) -> np.ndarray:
        """Числа колонки по строкам; пропуск или нечисло → NaN."""
        return self._numbers[column] if column in self._numbers else self._parse(column)

    def labels(self, column: str) -> list[str]:
        """Метки колонки по строкам; пропуск → "" (разбор один раз на вызов)."""
        return self.memo(f"labels:{column}", lambda: [
            "" if is_missing(v) else v.strip() for v in self.table.column_values(column)])

    def columns_of(self, kind: str) -> list[str]:
        """Имена колонок определённого типа (numeric, categorical …)."""
        return [p.name for p in self.table.profiles if p.detected_type.value == kind]

    @cached_property
    def _numbers(self) -> dict[str, np.ndarray]:
        return {}

    def _parse(self, column: str) -> np.ndarray:
        decimal = self.table.dialect.decimal
        out = []
        for raw in self.table.column_values(column):
            number = None if is_missing(raw) else parse_number(raw, decimal)
            out.append(np.nan if number is None else number)
        arr = np.asarray(out, dtype=float)
        self._numbers[column] = arr
        return arr


_HOLE = re.compile(r"\{(\w+)((?:\|[^{}|]+)*)\}")


def plural_form(n: Any, forms: list[str]) -> str:
    """Форма слова при числе n: две формы (1 / много) или три русские (1 / 2–4 / 5+).

    Дробное число (и любой float: он печатается с точкой) в русском требует
    вторую форму: «в 2.5 раза». Та же функция — ``pluralForm`` во фронтенде.
    """
    if len(forms) == 2:
        return forms[0] if n == 1 else forms[1]
    if isinstance(n, bool) or not isinstance(n, Integral):
        return forms[1]
    k = abs(int(n))
    if k % 10 == 1 and k % 100 != 11:
        return forms[0]
    return forms[1] if 2 <= k % 10 <= 4 and not 12 <= k % 100 <= 14 else forms[2]


def _fill(note: str, params: dict[str, Any]) -> str:
    """Русский фолбэк: {param} — значение, {param|форма|…} — слово в нужном числе.

    Неизвестный параметр остаётся как есть.
    """
    def put(m: re.Match) -> str:
        name, forms = m.group(1), m.group(2)
        if name not in params:
            return m.group(0)
        return plural_form(params[name], forms[1:].split("|")) if forms else str(params[name])

    return _HOLE.sub(put, note)


def recognize(table: Any, roles: dict[str, str] | None = None,
              cls: str | None = None, method: str | None = None) -> dict[str, Any]:
    """Прогнать реализованные распознаватели (``cls`` — только этого класса).

    ``method`` — метод, открытый в форме: правила одной ветки (сверхдисперсия
    GLM) не срабатывают, пока пользователь в другой.

    Возвращает реестр (метаданные всех правил, в т.ч. ещё не реализованных),
    список сработавших (id, узел, ветка, сила, сообщение для перевода) и
    ``errors`` — правила, упавшие с исключением: ``{id, error}``.
    Ошибка одного правила не роняет остальные: оно не попадает в ``fired``,
    но и не выглядит как «проверено, всё в порядке» — запись остаётся в ``errors``.
    Карта зовёт структурные сразу, расчётные — вторым вызовом (раздел 8).
    """
    from core.validation import recognizers  # noqa: F401  регистрирует правила

    ctx = Context(table, roles, method)
    fired, errors = [], []
    for rec in REGISTRY:
        if rec.fn is None or (cls is not None and rec.cls != cls):
            continue
        try:
            signal = rec.fn(ctx)
        except Exception as exc:  # noqa: BLE001 — сбой правила ≠ сбой карты
            signal = None
            errors.append({"id": rec.id,
                           "error": f"{type(exc).__name__}: {exc}"[:_ERROR_LIMIT]})
        if signal is not None:
            fired.append({**rec.meta(), "strength": signal.strength or rec.strength, "message": msg(
                f"rec_{rec.id.replace('.', '_')}", _fill(signal.note, signal.params),
                **signal.params)})
    return {"registry": [r.meta() for r in REGISTRY], "fired": fired, "errors": errors}
