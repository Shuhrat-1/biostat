"""Однофакторный дисперсионный анализ и множественные сравнения (гл. 3, 8).

Однофакторный ANOVA не зависит от конвенции sum of squares (Type I/II/III
совпадают для одного фактора) — расхождений между пакетами нет. Проблема
конвенций всплывёт позже, на факторных схемах.

Пост-хок: Tukey HSD (контроль familywise error для всех попарных сравнений).
Все функции возвращают ``StatResult`` из единой модели отчёта.
"""

from __future__ import annotations

import numpy as np
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd

from core.report.schema import Estimate, Severity, StatResult
from core.stats.guards import check_group_sizes, note_single_groups, refuse_constant
from core.stats.hypothesis import _refuse_flat_groups, levene_p_value
from core.stats.normality_rule import check_normality

_ASSUMPTION_ALPHA = 0.05
_SHAPIRO_MIN = 3
_SHAPIRO_MAX = 5000


def _clean_group(data: np.ndarray | list[float]) -> np.ndarray:
    """Привести группу к 1-D массиву float без NaN."""
    arr = np.asarray(data, dtype=float).ravel()
    return arr[~np.isnan(arr)]


def _pooled_residuals(groups: list[np.ndarray]) -> np.ndarray:
    """Остатки внутри групп (значение минус среднее своей группы)."""
    return np.concatenate([g - g.mean() for g in groups])


def one_way_anova(
    *groups: np.ndarray | list[float],
    labels: list[str] | None = None,
) -> StatResult:
    """Однофакторный ANOVA: сравнение средних нескольких групп.

    Проверяет гомогенность дисперсий (Левене) и нормальность остатков
    (Шапиро-Уилк), предупреждая при нарушении. Заполняет полную таблицу
    ANOVA (SS, df, MS, F) в statistics.
    """
    clean = [_clean_group(g) for g in groups]
    k = len(clean)
    if k < 2:
        result = StatResult(method="one_way_anova")
        result.add_warning("too_few_groups", "Нужно ≥ 2 групп", Severity.ERROR)
        return result

    if labels is None:
        labels = [f"g{i + 1}" for i in range(k)]
    elif len(labels) != k:
        raise ValueError("Число меток не совпадает с числом групп")

    sizes = [g.size for g in clean]
    n_total = int(sum(sizes))
    result = StatResult(
        method="one_way_anova",
        n=n_total,
        parameters={"labels": labels, "group_sizes": sizes},
    )
    if not check_group_sizes(result, sizes, labels) or _refuse_flat_groups(result, clean):
        return result

    # F-тест.
    f_res = stats.f_oneway(*clean)
    df_between = k - 1
    df_within = n_total - k

    # Таблица ANOVA вручную для полной прозрачности.
    grand_mean = np.concatenate(clean).mean()
    ss_between = float(sum(g.size * (g.mean() - grand_mean) ** 2 for g in clean))
    ss_within = float(sum(((g - g.mean()) ** 2).sum() for g in clean))
    ss_total = ss_between + ss_within
    ms_between = ss_between / df_between
    ms_within = ss_within / df_within

    result.p_value = float(f_res.pvalue)
    result.statistics = {
        "F": float(f_res.statistic),
        "df_between": df_between,
        "df_within": df_within,
        "ss_between": ss_between,
        "ss_within": ss_within,
        "ss_total": ss_total,
        "ms_between": ms_between,
        "ms_within": ms_within,
        "eta_squared": ss_between / ss_total if ss_total > 0 else float("nan"),
        **_extra_effect_sizes(ss_between, ss_total, ms_within, df_between),
    }
    for lab, g in zip(labels, clean):
        result.estimates.append(Estimate(name=f"mean_{lab}", value=float(g.mean())))

    _check_anova_assumptions(clean, result)
    return result


def omega_squared(ss_between: float, ss_total: float, ms_within: float, df_between: int) -> float:
    """ω² = (SS_b − df_b·MS_w) / (SS_t + MS_w) [предл.: Hays 1963].

    Менее смещённая оценка доли объяснённой дисперсии, чем η² (Witte, стр. 311);
    при F < 1 становится отрицательной — усекаем до 0.
    """
    denom = ss_total + ms_within
    if denom <= 0:
        return float("nan")
    return max(0.0, (ss_between - df_between * ms_within) / denom)


def _extra_effect_sizes(
    ss_between: float, ss_total: float, ms_within: float, df_between: int
) -> dict[str, float]:
    """Новые ключи W2: ω² и объединённое SD = √MS_within (Witte, стр. 317)."""
    return {
        "omega_squared": omega_squared(ss_between, ss_total, ms_within, df_between),
        "pooled_sd": float(np.sqrt(ms_within)),
    }


def _check_anova_assumptions(groups: list[np.ndarray], result: StatResult) -> None:
    """Проверить гомогенность дисперсий и нормальность остатков."""
    _check_variances(groups, result)
    _check_residual_normality(groups, result)


def _check_variances(groups: list[np.ndarray], result: StatResult) -> None:
    """Левене; при вырожденном тесте (группы по 2) — пометка вместо ложного сигнала."""
    levene_p = levene_p_value(*groups)
    if levene_p is None:
        result.add_warning(
            "levene_undefined",
            "Тест Левене не определён (слишком мало наблюдений в группах); "
            "равенство дисперсий не проверено.",
            Severity.INFO,
        )
    else:
        result.statistics["levene_p"] = levene_p
    if levene_p is not None and levene_p < _ASSUMPTION_ALPHA:
        result.add_warning(
            "variance_heterogeneity",
            f"Тест Левене указывает на неравенство дисперсий (p={levene_p:.4f}). "
            f"Рассмотри тест Уэлча ANOVA или Краскела-Уоллиса.",
            Severity.WARNING,
        )


def _check_residual_normality(groups: list[np.ndarray], result: StatResult) -> None:
    """Шапиро–Уилк по объединённым остаткам; вывод — по общему с картой правилу.

    Совет — по книге: перестановочный тест сохраняет F и средние [кн. стр. 102],
    при правой асимметрии — трансформация [кн. стр. 115]; ранговый тест
    Краскела–Уоллиса — для баллов и рангов (аудит 02-06).
    """
    check = check_normality(_pooled_residuals(groups), min(g.size for g in groups))
    if check is None:
        return
    result.statistics["shapiro_p_residuals"] = check.p
    if check.violated:
        result.add_warning(
            "residuals_not_normal",
            f"Остатки отклоняются от нормальности (Шапиро–Уилк p = {check.p:.4f}): "
            "перестановочный тест сохраняет F и средние; при правой асимметрии — "
            "трансформация. Краскел–Уоллис — для баллов и рангов.",
            Severity.WARNING, params={"p": f"{check.p:.4f}"})


def tukey_hsd(
    *groups: np.ndarray | list[float],
    labels: list[str] | None = None,
    alpha: float = 0.05,
) -> StatResult:
    """Пост-хок Tukey HSD: все попарные сравнения с контролем FWER.

    Применяется после значимого ANOVA. Каждое сравнение даёт разность
    средних, скорректированный p и доверительный интервал.

    Конвенция знака (как в statsmodels): ``mean_diff = mean(group2) -
    mean(group1)``. Положительное значение означает, что group2 больше.
    ``cohens_d`` в каждой строке — та же разность в единицах √MS_within
    (Witte, гл. 16.10), знак тот же.
    """
    clean = [_clean_group(g) for g in groups]
    k = len(clean)
    if k < 2:
        result = StatResult(method="tukey_hsd", parameters={"alpha": alpha})
        result.add_warning("too_few_groups", "Нужно ≥ 2 групп", Severity.ERROR)
        return result

    if labels is None:
        labels = [f"g{i + 1}" for i in range(k)]
    elif len(labels) != k:
        raise ValueError("Число меток не совпадает с числом групп")

    values = np.concatenate(clean)
    result = StatResult(
        method="tukey_hsd",
        n=int(values.size),
        parameters={"alpha": alpha, "labels": labels},
    )
    if _refuse_flat_groups(result, clean):
        return result
    group_col = np.concatenate([[lab] * g.size for lab, g in zip(labels, clean)])
    res = pairwise_tukeyhsd(values, group_col, alpha=alpha)
    note_single_groups(result, [g.size for g in clean], labels)
    ms_within, _ = _pooled_variance(clean)
    sd = float(np.sqrt(ms_within))
    comparisons = []
    for i, (g1, g2) in enumerate(_pairs(res.groupsunique.tolist())):
        comparisons.append(
            {
                "group1": g1,
                "group2": g2,
                "mean_diff": float(res.meandiffs[i]),
                "p_adj": float(res.pvalues[i]),
                "ci_lower": float(res.confint[i, 0]),
                "ci_upper": float(res.confint[i, 1]),
                "reject": bool(res.reject[i]),
                # Witte, ф. 16.10: d = разность / √MS_within.
                "cohens_d": float(res.meandiffs[i]) / sd if sd > 0 else float("nan"),
            }
        )
    result.parameters["comparisons"] = comparisons
    result.statistics["ms_within"] = float(ms_within)
    result.statistics["pooled_sd"] = sd
    result.statistics["n_comparisons"] = len(comparisons)
    result.statistics["n_significant"] = sum(c["reject"] for c in comparisons)
    return result


def _pairs(items: list[str]) -> list[tuple[str, str]]:
    """Все неупорядоченные пары в том же порядке, что даёт statsmodels."""
    return [
        (items[i], items[j])
        for i in range(len(items))
        for j in range(i + 1, len(items))
    ]


def kruskal_wallis(
    *groups: np.ndarray | list[float],
    labels: list[str] | None = None,
) -> StatResult:
    """Краскел-Уоллис — непараметрический аналог однофакторного ANOVA.

    Не требует нормальности и гомогенности дисперсий; сравнивает
    распределения по рангам. Новые ключи (Witte, гл. 20.5): суммы рангов,
    H без поправки на совпадения (как в книге) и поправка C.
    """
    clean = [_clean_group(g) for g in groups]
    k = len(clean)
    result = StatResult(method="kruskal_wallis")
    if k < 2:
        result.add_warning("too_few_groups", "Нужно ≥ 2 групп", Severity.ERROR)
        return result
    if any(g.size < 1 for g in clean):
        result.add_warning("empty_group", "Все группы должны быть непусты", Severity.ERROR)
        return result

    if labels is None:
        labels = [f"g{i + 1}" for i in range(k)]
    result.n = int(sum(g.size for g in clean))
    if refuse_constant(result, np.concatenate(clean)):  # scipy: исключение на английском
        return result
    res = stats.kruskal(*clean)
    result.p_value = float(res.pvalue)
    result.parameters["labels"] = labels
    result.statistics = {"H": float(res.statistic), "df": k - 1}
    note_single_groups(result, [g.size for g in clean], labels)
    for lab, g in zip(labels, clean):
        result.estimates.append(
            Estimate(name=f"median_{lab}", value=float(np.median(g)))
        )
    result.statistics.update(kruskal_rank_sums(clean, labels))
    return result


def kruskal_rank_sums(groups: list[np.ndarray], labels: list[str]) -> dict[str, float]:
    """Новые ключи (Witte, гл. 20.5, ф. 20.3): H без поправки на совпадения и сама поправка.

    H_uncorrected = 12/(N(N + 1))·Σ R²/n − 3(N + 1) — как в книге; scipy делит его на
    C = 1 − Σ(t³ − t)/(N³ − N) (H = H_uncorrected / C). Суммы рангов — rank_sum_<метка>.
    """
    pooled = np.concatenate(groups)
    ranks = stats.rankdata(pooled)
    n_total = pooled.size
    out: dict[str, float] = {}
    start, acc = 0, 0.0
    for lab, g in zip(labels, groups):
        r = float(ranks[start:start + g.size].sum())
        out[f"rank_sum_{lab}"] = r
        acc += r**2 / g.size
        start += g.size
    _, ties = np.unique(pooled, return_counts=True)
    out["H_uncorrected"] = 12 / (n_total * (n_total + 1)) * acc - 3 * (n_total + 1)
    out["tie_correction"] = float(1 - np.sum(ties**3 - ties) / (n_total**3 - n_total))
    return out


def treatment_means(
    *groups: np.ndarray | list[float],
    labels: list[str] | None = None,
    alpha: float = 0.05,
) -> StatResult:
    """Средние групп с SEM и ДИ по объединённой дисперсии, SED и LSD (гл. 4.4).

    Фон s² = ResMS однофакторного ANOVA на N − t df (стр. 84–87):
    SEM_j = √(s²/n_j), SED_jk = √(s²(1/n_j + 1/n_k)), LSD = t[α/2] × SED.
    Попарные p — без поправки на множественность (unprotected LSD).
    """
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha должен быть в (0, 1)")
    clean = [_clean_group(g) for g in groups]
    labels = _resolve_labels(labels, len(clean))
    result = StatResult(
        method="treatment_means",
        n=int(sum(g.size for g in clean)),
        parameters={"alpha": alpha, "labels": labels},
    )
    if not _means_guard(clean, result):
        return result

    s2, df = _pooled_variance(clean)
    t_crit = float(stats.t.ppf(1 - alpha / 2, df))
    result.statistics = {"residual_ms": s2, "df_resid": df, "t_crit": t_crit}
    _add_mean_estimates(clean, labels, s2, t_crit, 1 - alpha, result)
    result.parameters["comparisons"] = _lsd_comparisons(clean, labels, s2, df, t_crit)
    _add_common_lsd(clean, s2, t_crit, result)
    _check_anova_assumptions(clean, result)
    return result


def _add_common_lsd(
    groups: list[np.ndarray], s2: float, t_crit: float, result: StatResult
) -> None:
    """Общие SED и LSD при равной повторности; предупреждение о множественности."""
    sizes = {g.size for g in groups}
    if len(sizes) == 1:  # равная повторность → один SED на все пары (стр. 86)
        sed = float(np.sqrt(2 * s2 / sizes.pop()))
        result.statistics.update({"sed": sed, "lsd": t_crit * sed})
    if len(groups) > 2:
        result.add_warning(
            "unadjusted_comparisons",
            "Попарные p и ДИ разностей без поправки на множественность; "
            "для всех попарных сравнений используй Tukey HSD.",
            Severity.INFO,
        )


def _resolve_labels(labels: list[str] | None, k: int) -> list[str]:
    """Метки групп по умолчанию g1…gk; проверить длину заданных."""
    if labels is None:
        return [f"g{i + 1}" for i in range(k)]
    if len(labels) != k:
        raise ValueError("Число меток не совпадает с числом групп")
    return list(labels)


def _means_guard(groups: list[np.ndarray], result: StatResult) -> bool:
    """≥ 2 групп, остаточные df ≥ 1 и ненулевая остаточная дисперсия, иначе ошибка."""
    if len(groups) < 2:
        result.add_warning("too_few_groups", "Нужно ≥ 2 групп", Severity.ERROR)
        return False
    if not check_group_sizes(result, [g.size for g in groups], result.parameters["labels"]):
        return False
    if _pooled_variance(groups)[0] == 0:
        result.add_warning(
            "no_residual_variation",
            "Внутри групп нет вариации — SEM и SED равны нулю, ДИ не определены",
            Severity.ERROR,
        )
        return False
    return True


def _pooled_variance(groups: list[np.ndarray]) -> tuple[float, int]:
    """ResMS = Σ(y − ȳ_j)² / (N − t) и его df (стр. 80–81)."""
    df = int(sum(g.size for g in groups)) - len(groups)
    ss = float(sum(((g - g.mean()) ** 2).sum() for g in groups))
    return ss / df, df


def _add_mean_estimates(
    groups: list[np.ndarray],
    labels: list[str],
    s2: float,
    t_crit: float,
    level: float,
    result: StatResult,
) -> None:
    """Среднее каждой группы с SEM и ДИ на df остатка (стр. 85)."""
    for lab, g in zip(labels, groups):
        mean = float(g.mean())
        sem = float(np.sqrt(s2 / g.size))
        result.estimates.append(
            Estimate(
                name=f"mean_{lab}",
                value=mean,
                ci_lower=mean - t_crit * sem,
                ci_upper=mean + t_crit * sem,
                ci_level=level,
                std_error=sem,
            )
        )


def _lsd_comparisons(
    groups: list[np.ndarray],
    labels: list[str],
    s2: float,
    df: int,
    t_crit: float,
) -> list[dict[str, float | str]]:
    """Все пары: разность, SED, LSD, ДИ и p t-теста на df остатка (стр. 86–87).

    Знак как в tukey_hsd: mean_diff = mean(group2) − mean(group1).
    """
    rows = []
    for i, j in ((i, j) for i in range(len(groups)) for j in range(i + 1, len(groups))):
        diff = float(groups[j].mean() - groups[i].mean())
        sed = float(np.sqrt(s2 * (1 / groups[i].size + 1 / groups[j].size)))
        t_stat = diff / sed
        rows.append(
            {
                "group1": labels[i],
                "group2": labels[j],
                "mean_diff": diff,
                "sed": sed,
                "lsd": t_crit * sed,
                "ci_lower": diff - t_crit * sed,
                "ci_upper": diff + t_crit * sed,
                "t": t_stat,
                "p_unadjusted": float(2 * stats.t.sf(abs(t_stat), df)),
            }
        )
    return rows
