"""Проверка гипотез: t-тесты и непараметрические аналоги (гл. 2 книги).

Каждый тест проверяет свои допущения и предупреждает при нарушении,
подсказывая непараметрическую альтернативу. Все функции возвращают
``StatResult`` из единой модели отчёта.
"""

from __future__ import annotations

import numpy as np
from scipy import special, stats

from core.report.schema import Estimate, Severity, StatResult
from core.stats.guards import refuse_constant, refuse_no_residual
from core.stats.normality_rule import check_normality
from core.stats.hodges_lehmann import hl_one_sample, hl_two_sample
from core.stats.welch_rule import welch_advice

# Порог p для тестов на нарушение допущений (нормальность, равенство дисперсий).
_ASSUMPTION_ALPHA = 0.05
# Диапазон n, в котором тест Шапиро-Уилка осмыслен.
_SHAPIRO_MIN = 3
_SHAPIRO_MAX = 5000
_ALTERNATIVES = ("two-sided", "less", "greater")


def _clean(data: np.ndarray | list[float]) -> np.ndarray:
    """Привести вход к 1-D массиву float без NaN."""
    arr = np.asarray(data, dtype=float).ravel()
    return arr[~np.isnan(arr)]


def levene_p_value(*groups: np.ndarray) -> float | None:
    """p теста Левене или None, если тест вырожден.

    При группах из 2 наблюдений модули отклонений от медианы внутри
    группы равны, W = inf и p = 0 — ложный сигнал неравных дисперсий.
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        res = stats.levene(*groups)
    if not (np.isfinite(res.statistic) and np.isfinite(res.pvalue)):
        return None
    return float(res.pvalue)


_ADVICE_CODES = {"welch": "unequal_variance",
                 "welch_unbalanced": "unequal_variance_unbalanced",
                 "welch_liberal": "unequal_variance_liberal"}
_ADVICE_TEXT = {
    "welch": "SD групп различаются в {r} раза",
    "welch_unbalanced": "SD различаются в {r} раза при неравных n; большая SD — в "
                        "большей группе, P Стьюдента завышен (консервативен)",
    "welch_liberal": "SD различаются в {r} раза при неравных n; большая SD — в "
                     "меньшей группе, P Стьюдента занижен",
}


def _choose_equal_var(
    arr_a: np.ndarray, arr_b: np.ndarray, equal_var: bool | None, result: StatResult
) -> bool:
    """Стьюдент или Уэлч; при Стьюденте — совет Уэлча по правилу welch_rule.

    Левене считается как справка (levene_p). ``equal_var=None`` — выбор по
    тому же правилу, а не по P Левене.
    """
    levene_p = levene_p_value(arr_a, arr_b)
    if levene_p is not None:
        result.statistics["levene_p"] = levene_p
    advice = welch_advice(arr_a, arr_b)
    if advice is not None and not advice.reliable:
        if equal_var is not False:
            _note_small_samples(advice, result)
        return True if equal_var is None else equal_var
    if equal_var is None:
        return advice is None
    if equal_var and advice is not None:
        params = {"sd_ratio": round(advice.sd_ratio, 2), "n_ratio": round(advice.n_ratio, 2)}
        result.add_warning(
            _ADVICE_CODES[advice.case],
            _ADVICE_TEXT[advice.case].format(r=params["sd_ratio"])
            + ": рассмотри вариант Уэлча (параметр «Вариант»).",
            Severity.WARNING, params=params)
    return equal_var


def _note_small_samples(advice, result: StatResult) -> None:
    """Справка вместо совета Уэлча: при n < 8 отношение SD ненадёжно (welch_rule)."""
    params = {"sd_ratio": round(advice.sd_ratio, 2), "n_min": advice.n_min}
    result.add_warning(
        "unequal_variance_small_n",
        f"SD групп различаются в {params['sd_ratio']} раза, но в меньшей группе всего "
        f"{advice.n_min} наблюдений: по таким выборкам о дисперсиях судить нельзя.",
        Severity.INFO, params=params)


def _mean_diff_ci(res, confidence: float) -> tuple[float | None, float | None]:
    """ДИ разности средних того же варианта и направления, что и t.

    При одностороннем alternative одна граница бесконечна → None.
    """
    ci = res.confidence_interval(confidence_level=confidence)
    lo, hi = float(ci.low), float(ci.high)
    return (lo if np.isfinite(lo) else None, hi if np.isfinite(hi) else None)


def hedges_correction(df: float) -> float:
    """Точный множитель J Хеджеса: g = J · d [предл.: Hedges 1981].

    J = Γ(df/2) / (√(df/2) · Γ((df − 1)/2)); ≈ 1 − 3/(4·df − 1).
    """
    log_j = special.gammaln(df / 2) - special.gammaln((df - 1) / 2)
    return float(np.exp(log_j) / np.sqrt(df / 2))


def _cohens_d_pooled(arr_a: np.ndarray, arr_b: np.ndarray) -> tuple[float, float]:
    """d Коэна по объединённому SD и g Хеджеса [Witte, стр. 262, ф. 14.5].

    Объединённое SD — всегда, независимо от варианта t (Стьюдент/Уэлч).
    """
    df = arr_a.size + arr_b.size - 2
    ss = np.sum((arr_a - arr_a.mean()) ** 2) + np.sum((arr_b - arr_b.mean()) ** 2)
    sd_pooled = float(np.sqrt(ss / df))
    if sd_pooled == 0:
        return float("nan"), float("nan")
    d = float((arr_a.mean() - arr_b.mean()) / sd_pooled)
    return d, d * hedges_correction(df)


def _check_normality(
    arr: np.ndarray, result: StatResult, label: str, min_group_size: int | None = None,
    warn: bool = True,
) -> None:
    """Шапиро–Уилк; предупреждение — по общему с картой правилу (`normality_rule`).

    min_group_size — наименьшая группа, из которой собраны значения (по умолчанию
    всё n); warn = False — только записать P в статистику.
    """
    check = check_normality(arr, arr.size if min_group_size is None else min_group_size)
    if check is None:
        return
    result.statistics[f"shapiro_p_{label}"] = check.p
    if warn and check.violated:
        result.add_warning(
            "normality_violated",
            f"{label}: тест Шапиро–Уилка отклонил нормальность (p = {check.p:.4f}). "
            "Рассмотрите трансформацию или непараметрический аналог.",
            Severity.WARNING, params={"p": f"{check.p:.4f}"})


def _refuse_flat_groups(result: StatResult, groups: list[np.ndarray]) -> bool:
    """Отказ: все значения равны или внутри групп нет вариации; True — остановиться."""
    pooled = np.concatenate(groups)
    within = float(sum(((g - g.mean()) ** 2).sum() for g in groups))
    total = float(((pooled - pooled.mean()) ** 2).sum())
    return refuse_constant(result, pooled) or refuse_no_residual(result, within, total)


def one_sample_t(
    data: np.ndarray | list[float],
    popmean: float,
    alternative: str = "two-sided",
    confidence: float = 0.95,
) -> StatResult:
    """Одновыборочный t-тест: среднее выборки против заданного значения.

    Оценка (Witte, гл. 13.8): ДИ для μ того же направления, что и t;
    d = (X̄ − μ_hyp) / s [предл.: Cohen 1988; Witte, стр. 213 — эффект в SD].
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")

    arr = _clean(data)
    result = StatResult(
        method="one_sample_t",
        n=arr.size,
        parameters={"popmean": popmean, "alternative": alternative},
    )
    if arr.size < 2:
        result.add_warning("n_too_small", "n < 2: тест невозможен", Severity.ERROR)
        return result
    if refuse_constant(result, arr):
        return result

    res = stats.ttest_1samp(arr, popmean, alternative=alternative)
    mean = float(np.mean(arr))
    result.p_value = float(res.pvalue)
    result.statistics = {
        "t": float(res.statistic),
        "df": arr.size - 1,
        "mean": mean,
        "mean_diff": mean - popmean,
    }
    _add_one_sample_effect(result, res, arr, popmean, confidence)
    _check_normality(arr, result, "sample")
    return result


def _add_one_sample_effect(
    result: StatResult, res, arr: np.ndarray, popmean: float, confidence: float
) -> None:
    """Записать SE, ДИ для μ и d новыми ключами [Witte, стр. 240–242].

    ДИ scipy строится для μ (а не для X̄ − μ_hyp).
    """
    mean = float(arr.mean())
    sd = float(arr.std(ddof=1))
    se = float(sd / np.sqrt(arr.size))
    lo, hi = _mean_diff_ci(res, confidence)
    d = (mean - popmean) / sd if sd > 0 else float("nan")
    result.statistics.update(
        {
            "sd": sd,
            "se_mean": se,
            "ci_level": confidence,
            "ci_lower": lo,
            "ci_upper": hi,
            "cohens_d": float(d),
        }
    )
    result.estimates.append(
        Estimate(
            name="mean", value=mean, ci_lower=lo, ci_upper=hi,
            ci_level=confidence, std_error=se,
        )
    )
    result.estimates.append(Estimate(name="cohens_d", value=float(d)))


_VARIANTS = {"student": True, "welch": False, "auto": None}


def two_sample_t(
    a: np.ndarray | list[float],
    b: np.ndarray | list[float],
    equal_var: bool | None = True,
    alternative: str = "two-sided",
    confidence: float = 0.95,
    variant: str | None = None,
) -> StatResult:
    """Двухвыборочный t-тест: сравнение средних двух групп.

    По умолчанию — Стьюдент с объединённой дисперсией (Welham, гл. 2.4.2;
    решение BioStat 8.11.2026): Левене считается как справка, при неравных
    SD (правило welch_rule) — предупреждение с советом Уэлча. ``variant``
    (из интерфейса) перекрывает ``equal_var``: "student", "welch" или "auto"
    (выбор по тому же правилу, ``equal_var=None``).

    Размер эффекта (Witte, гл. 14.8–14.9): ДИ разности того же варианта
    и направления, что и t; d Коэна по объединённому SD; g Хеджеса.
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")

    if variant is not None:
        if variant not in _VARIANTS:
            raise ValueError(f"variant ∈ {tuple(_VARIANTS)}")
        equal_var = _VARIANTS[variant]
    arr_a, arr_b = _clean(a), _clean(b)
    result = StatResult(
        method="two_sample_t",
        n=arr_a.size + arr_b.size,
        parameters={"alternative": alternative},
    )
    if arr_a.size < 2 or arr_b.size < 2:
        result.add_warning(
            "n_too_small", "Каждая группа должна иметь n ≥ 2", Severity.ERROR
        )
        return result
    if _refuse_flat_groups(result, [arr_a, arr_b]):
        return result

    # Проверка равенства дисперсий (Левене) — определяет выбор варианта.
    equal_var = _choose_equal_var(arr_a, arr_b, equal_var, result)

    res = stats.ttest_ind(
        arr_a, arr_b, equal_var=equal_var, alternative=alternative
    )
    mean_a, mean_b = float(np.mean(arr_a)), float(np.mean(arr_b))
    result.p_value = float(res.pvalue)
    result.parameters["equal_var"] = equal_var
    result.parameters["variant"] = "student" if equal_var else "welch"
    result.statistics.update(
        {
            "t": float(res.statistic),
            "df": float(res.df) if hasattr(res, "df") else arr_a.size + arr_b.size - 2,
            "mean_a": mean_a,
            "mean_b": mean_b,
            "mean_diff": mean_a - mean_b,
        }
    )
    _add_two_sample_effect(result, res, arr_a, arr_b, confidence)
    # P по группам — в статистику; предупреждение — по остаткам модели двух групп,
    # как сигнал карты B4.1 (аудит 02-06).
    _check_normality(arr_a, result, "group_a", warn=False)
    _check_normality(arr_b, result, "group_b", warn=False)
    residuals = np.concatenate([arr_a - arr_a.mean(), arr_b - arr_b.mean()])
    _check_normality(residuals, result, "residuals", min(arr_a.size, arr_b.size))
    return result


def _add_two_sample_effect(
    result: StatResult,
    res,
    arr_a: np.ndarray,
    arr_b: np.ndarray,
    confidence: float,
) -> None:
    """Записать ДИ разности, d Коэна и g Хеджеса новыми ключами."""
    diff = float(arr_a.mean() - arr_b.mean())
    se = float(diff / res.statistic) if res.statistic else float("nan")
    lo, hi = _mean_diff_ci(res, confidence)
    d, g = _cohens_d_pooled(arr_a, arr_b)
    result.statistics.update(
        {
            "se_diff": se,
            "ci_level": confidence,
            "ci_lower": lo,
            "ci_upper": hi,
            "cohens_d": d,
            "hedges_g": g,
        }
    )
    result.estimates.append(
        Estimate(
            name="mean_diff", value=diff, ci_lower=lo, ci_upper=hi,
            ci_level=confidence, std_error=se,
        )
    )
    result.estimates.append(Estimate(name="cohens_d", value=d))
    result.estimates.append(Estimate(name="hedges_g", value=g))


def paired_t(
    a: np.ndarray | list[float],
    b: np.ndarray | list[float],
    alternative: str = "two-sided",
    confidence: float = 0.95,
) -> StatResult:
    """Парный t-тест: разности связанных измерений (до/после).

    Размер эффекта (Witte, гл. 15.6): ДИ для μD того же направления, что и t;
    d_z = D̄ / s_D — по SD разностей, с d независимых выборок несравним.
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")

    arr_a = np.asarray(a, dtype=float).ravel()
    arr_b = np.asarray(b, dtype=float).ravel()
    if arr_a.size != arr_b.size:
        raise ValueError("Парный тест требует выборки равной длины")

    # Удаляем пары, где хотя бы одно значение — NaN.
    mask = ~(np.isnan(arr_a) | np.isnan(arr_b))
    arr_a, arr_b = arr_a[mask], arr_b[mask]
    diff = arr_a - arr_b

    result = StatResult(
        method="paired_t",
        n=diff.size,
        parameters={"alternative": alternative},
    )
    if diff.size < 2:
        result.add_warning("n_too_small", "n < 2: тест невозможен", Severity.ERROR)
        return result
    if refuse_constant(result, diff):  # все разности равны: SD разностей = 0
        return result

    res = stats.ttest_rel(arr_a, arr_b, alternative=alternative)
    mean_diff = float(np.mean(diff))
    result.p_value = float(res.pvalue)
    result.statistics = {
        "t": float(res.statistic),
        "df": diff.size - 1,
        "mean_diff": mean_diff,
    }
    _add_paired_effect(result, res, diff, confidence)
    _check_normality(diff, result, "differences")
    return result


def _add_paired_effect(
    result: StatResult, res, diff: np.ndarray, confidence: float
) -> None:
    """Записать ДИ для μD и d_z новыми ключами [Witte, стр. 281–283]."""
    mean_diff = float(diff.mean())
    sd_diff = float(diff.std(ddof=1))
    se = sd_diff / np.sqrt(diff.size)
    lo, hi = _mean_diff_ci(res, confidence)
    d_z = mean_diff / sd_diff if sd_diff > 0 else float("nan")
    result.statistics.update(
        {
            "sd_diff": sd_diff,
            "se_diff": float(se),
            "ci_level": confidence,
            "ci_lower": lo,
            "ci_upper": hi,
            "cohens_dz": float(d_z),
        }
    )
    result.estimates.append(
        Estimate(
            name="mean_diff", value=mean_diff, ci_lower=lo, ci_upper=hi,
            ci_level=confidence, std_error=float(se),
        )
    )
    result.estimates.append(Estimate(name="cohens_dz", value=float(d_z)))


def mann_whitney(
    a: np.ndarray | list[float],
    b: np.ndarray | list[float],
    alternative: str = "two-sided",
    confidence: float = 0.95,
) -> StatResult:
    """Тест Манна-Уитни U — непараметрический аналог двухвыборочного t.

    Не требует нормальности; сравнивает распределения двух независимых групп.
    Новые ключи (Witte, гл. 20.3; пакет W2): суммы рангов, U_min — меньшее из U₁, U₂
    (ф. 20.1, как в таблицах книги); сдвиг Ходжеса–Лемана a − b с ДИ
    [предл.: Hodges & Lehmann 1963].
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")

    arr_a, arr_b = _clean(a), _clean(b)
    result = StatResult(
        method="mann_whitney",
        n=arr_a.size + arr_b.size,
        parameters={"alternative": alternative},
    )
    if arr_a.size < 1 or arr_b.size < 1:
        result.add_warning("empty_group", "Обе группы должны быть непусты", Severity.ERROR)
        return result

    res = stats.mannwhitneyu(arr_a, arr_b, alternative=alternative)
    result.p_value = float(res.pvalue)
    result.statistics = {
        "U": float(res.statistic),
        "median_a": float(np.median(arr_a)),
        "median_b": float(np.median(arr_b)),
    }
    _add_mann_whitney_extras(result, arr_a, arr_b, confidence)
    return result


def _add_mann_whitney_extras(
    result: StatResult, arr_a: np.ndarray, arr_b: np.ndarray, confidence: float
) -> None:
    """Суммы рангов, U_min (Witte, ф. 20.1) и сдвиг Ходжеса–Лемана — новыми ключами."""
    ranks = stats.rankdata(np.concatenate([arr_a, arr_b]))
    r_a, r_b = float(ranks[: arr_a.size].sum()), float(ranks[arr_a.size:].sum())
    n_a, n_b = arr_a.size, arr_b.size
    u_a = r_a - n_a * (n_a + 1) / 2  # = U scipy: пары, где a > b
    hl = hl_two_sample(arr_a, arr_b, 1 - confidence)
    result.parameters["hl_ci_method"] = hl.pop("hl_ci_method")  # exact | normal
    result.statistics.update({"rank_sum_a": r_a, "rank_sum_b": r_b,
                              "U_min": float(min(u_a, n_a * n_b - u_a)),
                              "ci_level": confidence, **hl})
    result.estimates.append(Estimate(name="hl_shift", value=hl["hl_shift"],
                                     ci_lower=hl["hl_ci_lower"], ci_upper=hl["hl_ci_upper"],
                                     ci_level=confidence))


def wilcoxon(
    a: np.ndarray | list[float],
    b: np.ndarray | list[float],
    alternative: str = "two-sided",
    confidence: float = 0.95,
) -> StatResult:
    """Знаково-ранговый тест Уилкоксона — непараметрический аналог парного t.

    Новые ключи (Witte, гл. 20.4; пакет W2): R⁺, R⁻, число ненулевых разностей,
    T_min = min(R⁺, R⁻) (ф. 20.2); оценка Ходжеса–Лемана центра разностей a − b
    (медиана средних Уолша) с ДИ [предл.: Hodges & Lehmann 1963].
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")

    arr_a = np.asarray(a, dtype=float).ravel()
    arr_b = np.asarray(b, dtype=float).ravel()
    if arr_a.size != arr_b.size:
        raise ValueError("Тест Уилкоксона требует выборки равной длины")

    mask = ~(np.isnan(arr_a) | np.isnan(arr_b))
    arr_a, arr_b = arr_a[mask], arr_b[mask]

    result = StatResult(
        method="wilcoxon",
        n=arr_a.size,
        parameters={"alternative": alternative},
    )
    if arr_a.size < 1:
        result.add_warning("empty", "Нет данных после очистки", Severity.ERROR)
        return result
    if not np.any(arr_a - arr_b):  # scipy здесь бросает исключение на английском
        refuse_constant(result, arr_a - arr_b)
        return result

    res = stats.wilcoxon(arr_a, arr_b, alternative=alternative)
    result.p_value = float(res.pvalue)
    result.statistics = {
        "W": float(res.statistic),
        "median_diff": float(np.median(arr_a - arr_b)),
    }
    _add_wilcoxon_extras(result, arr_a - arr_b, confidence)
    return result


def _add_wilcoxon_extras(result: StatResult, diff: np.ndarray, confidence: float) -> None:
    """R⁺, R⁻, T_min (нули отброшены, ф. 20.2) и оценка Ходжеса–Лемана — новыми ключами."""
    nonzero = diff[diff != 0]
    ranks = stats.rankdata(np.abs(nonzero))
    r_plus, r_minus = float(ranks[nonzero > 0].sum()), float(ranks[nonzero < 0].sum())
    hl = hl_one_sample(diff, 1 - confidence)
    result.parameters["hl_ci_method"] = hl.pop("hl_ci_method")  # exact | normal
    result.statistics.update({"r_plus": r_plus, "r_minus": r_minus,
                              "n_nonzero": int(nonzero.size), "T_min": min(r_plus, r_minus),
                              "ci_level": confidence, **hl})
    result.estimates.append(Estimate(name="hl_shift", value=hl["hl_shift"],
                                     ci_lower=hl["hl_ci_lower"], ci_upper=hl["hl_ci_upper"],
                                     ci_level=confidence))


def one_sample_wilcoxon(
    data: np.ndarray | list[float],
    popmean: float = 0.0,
    alternative: str = "two-sided",
    confidence: float = 0.95,
) -> StatResult:
    """Знаково-ранговый тест Уилкоксона одной выборки: центр симметрии = μ₀.

    Ранговый аналог one_sample_t [предл.: Wilcoxon 1945; Hollander & Wolfe 1999,
    гл. 3]: тест по разностям x − μ₀ (нули отбрасываются), R⁺, R⁻, T_min как у
    wilcoxon; оценка Ходжеса–Лемана центра (псевдомедиана) с ДИ. Допущение —
    симметрия распределения относительно центра.
    """
    if alternative not in _ALTERNATIVES:
        raise ValueError(f"alternative ∈ {_ALTERNATIVES}")
    if not 0 < confidence < 1:
        raise ValueError("confidence ∈ (0, 1)")
    arr = _clean(data)
    result = StatResult(method="one_sample_wilcoxon", n=arr.size,
                        parameters={"alternative": alternative, "popmean": popmean})
    if arr.size < 1:
        result.add_warning("empty", "Нет данных после очистки", Severity.ERROR)
        return result
    diff = arr - popmean
    if np.all(diff == 0):
        result.add_warning("wilcoxon_all_zero",
                           "Все значения равны μ₀: ненулевых разностей нет, тест не определён.",
                           Severity.ERROR)
        return result
    res = stats.wilcoxon(diff, alternative=alternative)
    result.p_value = float(res.pvalue)
    result.statistics = {"W": float(res.statistic), "median": float(np.median(arr)),
                         "median_diff": float(np.median(diff))}
    _add_wilcoxon_extras(result, diff, confidence)
    _add_location(result, popmean, confidence)
    return result


def _add_location(result: StatResult, popmean: float, confidence: float) -> None:
    """Псевдомедиана μ₀ + сдвиг ХЛ с ДИ (границы None — ДИ не ограничен)."""
    st = result.statistics
    shift = {k: (None if st[k] is None else popmean + st[k])
             for k in ("hl_shift", "hl_ci_lower", "hl_ci_upper")}
    st.update({"hl_location": shift["hl_shift"], "hl_location_ci_lower": shift["hl_ci_lower"],
               "hl_location_ci_upper": shift["hl_ci_upper"]})
    result.estimates.append(Estimate(name="hl_location", value=shift["hl_shift"],
                                     ci_lower=shift["hl_ci_lower"],
                                     ci_upper=shift["hl_ci_upper"], ci_level=confidence))
