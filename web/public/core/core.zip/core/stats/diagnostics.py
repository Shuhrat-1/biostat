"""Диагностика допущений модели через анализ остатков (гл. 5 книги).

Приоритетный модуль: именно проверка допущений отличает серьёзный
инструмент от калькулятора p-value. Проходит через всю прикладную
статистику книги.

Разделение ответственности: ядро НЕ рисует графики (это работа фронтенда
через Plotly), а отдаёт готовые числовые ряды. Четыре графика с обложки
книги: residual vs fitted, Q-Q plot, гистограмма остатков, scale-location.

Модуль принимает уже посчитанный результат регрессии — не пересчитывает
модель. Остатки берутся из ``StatResult.parameters``, куда их положил
модуль regression.
"""

from __future__ import annotations

import numpy as np
from scipy import stats
from statsmodels.stats.stattools import durbin_watson

from core.report.schema import Severity, StatResult
from core.stats.descriptive import sample_shape
from core.stats.guards import refuse_constant
from core.stats.normality_rule import check_normality

_ASSUMPTION_ALPHA = 0.05
_SHAPIRO_MIN = 3
_SHAPIRO_MAX = 5000
# Границы «нормы» для Дарбина-Уотсона: ~2 нет автокорреляции, <1 или >3 тревога.
_DW_LOW = 1.0
_DW_HIGH = 3.0


def _require_residuals(source: StatResult) -> tuple[np.ndarray, np.ndarray]:
    """Извлечь остатки и предсказанные значения из результата регрессии.

    Бросает ValueError, если источник не содержит сохранённых остатков.
    """
    p = source.parameters
    if "residuals" not in p or "fitted" not in p:
        raise ValueError(
            "Источник не содержит остатков. Передай результат "
            "simple_linear_regression."
        )
    return (
        np.asarray(p["residuals"], dtype=float),
        np.asarray(p["fitted"], dtype=float),
    )


def diagnose(source: StatResult) -> StatResult:
    """Полная диагностика допущений регрессии по её остаткам.

    Проверяет нормальность (Шапиро-Уилк), независимость (Дарбин-Уотсон)
    и готовит данные для четырёх диагностических графиков. Каждое
    нарушение фиксируется предупреждением.
    """
    resid, fitted = _require_residuals(source)
    n = resid.size
    result = StatResult(
        method="diagnose",
        n=n,
        parameters={"source_method": source.method},
    )
    if n < _SHAPIRO_MIN:
        result.add_warning("n_too_small", "Слишком мало остатков", Severity.ERROR)
        return result

    _test_normality(resid, result)
    _test_independence(resid, result)
    std_resid = _standardized(source, resid)
    result.parameters["plots"] = _build_plot_data(resid, fitted, std_resid)
    return result


def _standardized(source: StatResult, resid: np.ndarray) -> np.ndarray:
    """Стандартизованные остатки e/SE(e) по определению книги (стр. 95–96).

    Берутся сохранённые моделью (internally studentized); если их нет,
    запасной вариант — деление на SD остатков (только для старых результатов).
    """
    stored = source.parameters.get("std_residuals")
    if stored is not None and len(stored) == resid.size:
        return np.asarray(stored, dtype=float)
    std = resid.std(ddof=1)
    return resid / std if std > 0 else np.zeros_like(resid)


def _test_normality(resid: np.ndarray, result: StatResult) -> None:
    """Шапиро–Уилк по остаткам; вывод — по общему с картой правилу (`normality_rule`)."""
    check = check_normality(resid, resid.size)
    if check is None:
        return
    result.statistics["shapiro_p"] = check.p
    if check.violated:
        result.add_warning(
            "normality_violated",
            f"Остатки не прошли тест на нормальность (p = {check.p:.4f}). "
            "Рассмотрите трансформацию отклика (гл. 6) или непараметрический метод.",
            Severity.WARNING, params={"p": f"{check.p:.4f}"})


def _test_independence(resid: np.ndarray, result: StatResult) -> None:
    """Тест Дарбина-Уотсона на автокорреляцию остатков."""
    dw = float(durbin_watson(resid))
    result.statistics["durbin_watson"] = dw
    if dw < _DW_LOW or dw > _DW_HIGH:
        direction = "положительная" if dw < _DW_LOW else "отрицательная"
        result.add_warning(
            "autocorrelation",
            f"Дарбин-Уотсон = {dw:.3f}: возможна {direction} автокорреляция "
            f"остатков (ожидается ~2). Проверь порядок наблюдений.",
            Severity.WARNING,
        )


def _build_plot_data(
    resid: np.ndarray, fitted: np.ndarray, std_resid: np.ndarray
) -> dict:
    """Собрать числовые ряды для четырёх диагностических графиков.

    Ядро отдаёт данные, фронтенд рисует. Q-Q строится по стандартизованным
    остаткам с позициями (i − 0.375)/(n + 0.25) (стр. 101): точки должны
    лечь на линию 1:1.
    """
    n = std_resid.size
    osm = stats.norm.ppf((np.arange(1, n + 1) - 0.375) / (n + 0.25))
    osr = np.sort(std_resid)

    return {
        # 1. Residual vs Fitted — линейность и случайность разброса.
        "residual_vs_fitted": {
            "fitted": fitted.tolist(),
            "residuals": resid.tolist(),
        },
        # 2. Q-Q plot — нормальность.
        "qq": {
            "theoretical_quantiles": np.asarray(osm).tolist(),
            "sample_quantiles": np.asarray(osr).tolist(),
        },
        # 3. Гистограмма остатков — форма распределения.
        "histogram": {"residuals": resid.tolist()},
        # 4. Scale-Location — гомоскедастичность (корень |станд. остатка|).
        "scale_location": {
            "fitted": fitted.tolist(),
            "sqrt_abs_std_residuals": np.sqrt(np.abs(std_resid)).tolist(),
        },
    }


def normality_test(data: np.ndarray | list[float]) -> StatResult:
    """Отдельный тест нормальности произвольной выборки (Шапиро-Уилк).

    Полезен вне контекста регрессии — например, проверить сырые данные
    перед выбором параметрического или непараметрического теста.
    """
    arr = np.asarray(data, dtype=float).ravel()
    arr = arr[~np.isnan(arr)]
    result = StatResult(method="normality_test", n=arr.size)
    if not _SHAPIRO_MIN <= arr.size <= _SHAPIRO_MAX:
        result.add_warning(
            "n_out_of_range",
            f"Шапиро-Уилк осмыслен при {_SHAPIRO_MIN} ≤ n ≤ {_SHAPIRO_MAX}",
            Severity.ERROR,
        )
        return result
    if refuse_constant(result, arr):  # иначе W = 1, P = 1: «нормально», хотя проверять нечего
        return result

    res = stats.shapiro(arr)
    g1, g2 = sample_shape(arr)
    result.p_value = float(res.pvalue)
    result.statistics = {
        "W": float(res.statistic),
        # G₁ и G₂ — с поправкой на n, как в Excel / SPSS / GenStat (аудит 02-10);
        # подпись с формулой — на фронте (extraLabels.ts, STATS).
        "skewness": g1,
        "kurtosis": g2,
    }
    if res.pvalue < _ASSUMPTION_ALPHA:
        result.add_warning(
            "normality_violated",
            f"Данные не прошли тест на нормальность (p = {res.pvalue:.4f}).",
            Severity.WARNING, params={"p": f"{res.pvalue:.4f}"},
        )
    return result
